import os
import slack
import json
import logging
from time import sleep
import datetime
import pandas as pd
import boto3

# 定数
region = "ap-northeast-1"
s3_name = os.environ['S3_NAME']

# Logger定義
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def unix_to_datetime(unix):
    """
    UNIX時間 => datetime
    """
    try:
        return datetime.datetime.fromtimestamp(unix, datetime.timezone(datetime.timedelta(hours=9)))
    except Exception as e:
        logger.error(e)
        
def unix_to_datetime_messages(messages):
    formatted_messages = []
    for message in messages:
        formatted_message = {}
        message['ts'] = unix_to_datetime(float(message['ts']))
        formatted_message = message
        formatted_messages.append(formatted_message)
    return formatted_messages

class slack_channel():
    
    def __init__(self, token, channel, oldest, latest):
        self.token = token
        self.channel = channel
        self.oldest = oldest
        self.latest = latest
        
    def export_result(self):
        print('=======================エクスポート処理開始=========================')
        print("{} - {}".format(
            self.oldest.strftime('%Y/%m/%d %H:%M:%S'), 
            self.latest.strftime('%Y/%m/%d %H:%M:%S')
        ))
        print('Slack履歴取得(上限1000件)')
        history = self.get_history(1000)
        print('完了')
        print('unix時間を変換')
        history = unix_to_datetime_messages(history)
        print('完了')
        print('データフレーム化')
        df = pd.DataFrame(history)
        print('完了')
        try:
            ## parquetファイルの保存先ディレクトリを作成 / ファイルを定義
            base_dir = '/tmp'
            if len(str(self.oldest.month)) == 1:
                month = '0' + str(self.oldest.month)
            else:
                month = str(self.oldest.month)
            if len(str(self.oldest.date)) == 1:
                date = '0' + str(self.oldest.day)
            else:
                date = str(self.oldest.day)
            target_dir_path = '{year}/{month}/{date}/{channel_id}'.format(
                year = str(self.oldest.year),
                month = month,
                date = date,
                channel_id = self.channel
            )
            print('ローカルディレクトリ作成: {}'.format(os.path.join(base_dir, target_dir_path)))
            os.makedirs(os.path.join(base_dir, target_dir_path), exist_ok=True)
            print('完了')
            local_target_file_path = os.path.join(
                base_dir,
                target_dir_path,
                'slack_history.parquet'
            )
            s3_target_file_path = os.path.join(
                target_dir_path,
                'slack_history.parquet'
            )
            print('parquet出力')
            print(local_target_file_path)
            df.to_parquet(local_target_file_path, index = False)
            print('完了')
            s3_client = boto3.client('s3', region_name=region)
            print('S3にアップロード')
            s3_client.upload_file(local_target_file_path, s3_name, s3_target_file_path)
            print('完了')
            print('=======================エクスポート処理終了=========================')
        except Exception as e:
            logger.error(e)
        
    def get_history(self, limit):
        result = []
        client = slack.WebClient(token=self.token)
        response = client.conversations_history(
            channel=self.channel,
            limit=limit,
            oldest = str(self.oldest.timestamp()),
            latest = str(self.latest.timestamp())
        )
        if not response['ok']:
            print('okキーがTrueではありません')
            logger.info('処理を中止します')
            return
        messages = response['messages']
        for message in messages:
            tmp_dict = {}
            try:
                if 'thread_ts' not in message:
                    tmp_dict['type'] = message['type']
                    tmp_dict['user'] = message['user']
                    tmp_dict['ts'] = message['ts']
                    tmp_dict['text'] = message['text']
                    tmp_dict['thread_id'] = None
                    if 'attachments' in message:
                        message_list = []
                        for attachment in message['attachments']:
                            if 'blocks' in attachment:
                                for block in attachment['blocks']:
                                    if 'text' in block:
                                        message_list.append(block['text']['text'])
                                    elif 'fields' in block:
                                        for field in block['fields']:
                                            message_list.append(field['text'])
                                    elif 'elements' in block:
                                        for element in block['elements']:
                                            message_list.append(element['text'])
                                    else:
                                        logger.info('キーのリスト：{}'.format(str(block.keys())))
                        tmp_dict['attachments'] = '\n\n'.join(message_list)
                        if tmp_dict['text'] == "":
                            print("テキストがないため、アタッチメントに置き換えます")
                            tmp_dict['text'] = tmp_dict['attachments']
                    result.append(tmp_dict)
                else:
                    thread_messages = self.get_thread_messages(message['thread_ts'])
                    result.extend(thread_messages)
            except Exception as e:
                logger.error(e)  
        return result
    
    def get_thread_messages(self, thread_ts):
        result = []
        client = slack.WebClient(token=self.token)
        response = client.conversations_replies(
            channel=self.channel,
            ts = thread_ts,
            oldest = str(self.oldest.timestamp()),
            latest = str(self.latest.timestamp())
        )
        if not response['ok']:
            print('okキーがTrueではありません')
            logger.info('処理を中止します')
            return
        messages = response['messages']
        for message in messages:
            tmp_dict = {}
            try:
                tmp_dict['type'] = message['type']
                tmp_dict['user'] = message['user']
                tmp_dict['ts'] = message['ts']
                tmp_dict['text'] = message['text']
                tmp_dict['thread_id'] = thread_ts
                if 'attachments' in message:
                    message_list = []
                    for attachment in message['attachments']:
                        if 'blocks' in attachment:
                            for block in attachment['blocks']:
                                if 'text' in block:
                                    message_list.append(block['text']['text'])
                                elif 'fields' in block:
                                    for field in block['fields']:
                                        message_list.append(field['text'])
                                elif 'elements' in block:
                                    for element in block['elements']:
                                        message_list.append(element['text'])
                                else:
                                    logger.info('キーのリスト：{}'.format(str(block.keys())))
                    tmp_dict['attachments'] = '\n\n'.join(message_list)
                    if tmp_dict['text'] == "":
                            print("テキストがないため、アタッチメントに置き換えます")
                            tmp_dict['text'] = tmp_dict['attachments']
                result.append(tmp_dict)
            except Exception as e:
                logger.error(e)  
        return result
    
def lambda_handler(event, context):
    ## 現在の時間を取得
    dt_now_jst_aware = datetime.datetime.now(
        datetime.timezone(datetime.timedelta(hours=9))
    )
    dt_yesterday_jst_aware = dt_now_jst_aware - datetime.timedelta(days=1)
    oldest = dt_yesterday_jst_aware.replace(hour=0, minute=0, second=0)
    latest = dt_yesterday_jst_aware.replace(hour=23, minute=59, second=59)
    channel = slack_channel(event['token'], event['channel'], oldest, latest)
    channel.export_result()
    return 'Success'